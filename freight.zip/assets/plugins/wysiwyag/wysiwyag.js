$(function(e) {
	$('.content').richText();
	$('.content2').richText();
});