<?php
echo $_REQUEST['name'];
 ?>
